#pragma once
#include "../config.h"

namespace Aimbot {
    void Run();
}